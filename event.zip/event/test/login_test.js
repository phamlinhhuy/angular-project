'use strict';

describe('My test case for login component:', function() {

    beforeEach(module('eventApp.login'));

    describe('Test of login controller', function(){

       /* it('Test case 1: Should have login controller', inject(function($controller) {            
            var loginCtl = $controller('loginCtl');
            expect(loginCtl).toBeDefined();
        }));*/

        /*it('Test case 2: Should have event controller', inject(function($controller) {
            //spec body
            var formCtrl = $controller('formCtrl');
            expect(formCtrl).toBeDefined();
        }));*/


    });
});