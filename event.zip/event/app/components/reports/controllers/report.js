'use strict';

angular.module('eventApp.reports', [])
   
    .controller('reportsCtrl', function() {

    });