/*'use strict';

describe('Test filter', function() {

    beforeEach(module('myApp'));

    describe('Test of filter functions', function(){

    });
});*/