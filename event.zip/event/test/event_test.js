'use strict';

describe('My test case for event component:', function() {

    beforeEach(module('eventApp.events'));

    describe('Test of event controller', function(){

        /*it('Test case 1: Should have event controller', inject(function($controller) {
            
            var eventCtl = $controller('eventCtl');
            expect(eventCtl).toBeDefined();
        }));*/

        /*it('Test case 2: Should have event controller', inject(function($controller) {
            //spec body
            var formCtrl = $controller('formCtrl');
            expect(formCtrl).toBeDefined();
        }));*/


    });
    /*describe("=true:", function() {
   		it("Should be true", function() {
      		expect(true).toBeTruthy();
   		});
	});*/
});