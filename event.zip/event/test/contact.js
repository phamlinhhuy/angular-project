/*'use strict';

describe('Test of contact controller', function() {

    beforeEach(module('myApp.contacts'));

    describe('Test if contacts controller exist', function(){

        it('Test case: Should have contacts controller', inject(function($controller) {
            //spec body
            var contactsCtrl = $controller('ContactsCtrl');
            expect(contactsCtrl).toBeDefined();
        }));

    });
});*/